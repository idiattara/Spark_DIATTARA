# SDA_API
Transform data using NIFI
