# Confluent Platform 8.x (Kafka 4.x) — Multi-node Ansible (Brokers + Connect + ksqlDB + Control Center)

This package is derived from your single-node example and updated to:
- Use **three brokers** (KRaft controllers colocated on brokers)
- Put **group_vars** for **kafka_connect** and **ksqldb** (no hard-coded defaults)
- Deploy **Control Center** on a dedicated node

## Inventory (prod)

- Brokers/Controllers: 
  - kafkaBOK1SDA.eastus.cloudapp.azure.com
  - kafkaBOK2SDA.eastus.cloudapp.azure.com
  - kafkaBOK3SDA.eastus.cloudapp.azure.com
- Control Center, Connect, ksqlDB:
  - kafkaCONTSDA.eastus.cloudapp.azure.com

Adjust SSH settings in `inventories/prod/host_vars/*.yml` as needed.

## Run

```bash
ansible-playbook -i inventories/prod/hosts.ini site.yml
```

> Note: This demo uses PLAINTEXT listeners. For production, configure SASL/SSL and tighten replication/ISR settings as needed.
