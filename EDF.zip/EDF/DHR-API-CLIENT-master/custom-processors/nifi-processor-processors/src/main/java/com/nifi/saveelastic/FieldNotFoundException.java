package com.nifi.saveelastic;

public class FieldNotFoundException extends Exception {
    public FieldNotFoundException(String message) {
        super(message);
    }
}
