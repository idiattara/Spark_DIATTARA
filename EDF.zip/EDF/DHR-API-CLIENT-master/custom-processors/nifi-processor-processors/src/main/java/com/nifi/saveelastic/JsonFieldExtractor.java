package com.nifi.saveelastic;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.nifi.jsonextractcopyrightdiattara.FieldNotFoundException;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

public class JsonFieldExtractor {

    public static JsonNode extractFields(JsonNode inputJson, List<String> fieldsToExtract) throws FieldNotFoundException {
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode resultJson = mapper.createObjectNode();

        for (String field : fieldsToExtract) {
            JsonNode value = inputJson.get(field);
            if (value != null) {
                resultJson.set(field, value);
            } else {
                throw new FieldNotFoundException("Le champ '" + field + "' est manquant dans l'objet JSON.");
            }
        }

        return resultJson;
    }
    public static void main(String[] args) {
        String jsonString = "{\"nom\":\"ti\", \"age\":12, \"ville\":\"ttt\"}";
        List<String> fieldsToExtract = Arrays.asList("prenom", "age");
        ObjectMapper mapper = new ObjectMapper();

        try {
            JsonNode inputJson = mapper.readTree(jsonString);
            JsonNode resultJson = extractFields(inputJson, fieldsToExtract);
            System.out.println(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(resultJson));
        } catch (FieldNotFoundException e) {
            System.err.println("Erreur : " + e.getMessage());
        } catch (IOException e) {
            System.err.println("Erreur lors de la lecture du JSON d'entrée : " + e.getMessage());
        }
    }
}






