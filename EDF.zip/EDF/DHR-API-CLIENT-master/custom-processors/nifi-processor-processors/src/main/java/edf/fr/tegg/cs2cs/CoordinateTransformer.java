package edf.fr.tegg.cs2cs;

import com.nifi.jsonextractcopyrightdiattara.FieldNotFoundException;
import edf.fr.tegg.utils.Cs2csException;
import org.locationtech.proj4j.CRSFactory;
import org.locationtech.proj4j.CoordinateReferenceSystem;
import org.locationtech.proj4j.ProjCoordinate;
import org.locationtech.proj4j.CoordinateTransform;
import org.locationtech.proj4j.CoordinateTransformFactory;

import java.util.Arrays;
import java.util.List;

public class CoordinateTransformer {
/*
    public static void main(String[] args) throws FieldNotFoundException, Cs2csException {
        // Split the input arguments by semicolons
        List<String> params = Arrays.asList(args[0].split("\\s*;\\s*"));
        String sourceEPSG = params.get(3);
        String destEPSG = params.get(4);
        String zvide = "";
        double[] inputCoords = new double[3];

        try {
            inputCoords[0] = Double.parseDouble(params.get(0));
            inputCoords[1] = Double.parseDouble(params.get(1));
            if ("VIDE".equals(params.get(2))) {
                inputCoords[2] = Double.NaN;
                //zvide = ";null";
            } else {
                inputCoords[2] = Double.parseDouble(params.get(2));
            }
        } catch (NumberFormatException e) {
        }

        // Call the transformCoordinates method and print the result
        String res = transformCoordinates(sourceEPSG, destEPSG, inputCoords, zvide);
        System.out.println(res);
    }*/
    public static String transformCoordinates(String sourceEPSG, String destEPSG, double[] inputCoords, String zvide) throws FieldNotFoundException, Cs2csException {
        try {
            CRSFactory crsFactory = new CRSFactory();
            CoordinateReferenceSystem sourceCRS = crsFactory.createFromName("epsg:" + sourceEPSG);
            CoordinateReferenceSystem destCRS = crsFactory.createFromName("epsg:" + destEPSG);

            // Supposez que `z` reste constant pour l'exemple
            double z = inputCoords[2]; // Récupérez la valeur de z
            double[] xyCoords = { inputCoords[0], inputCoords[1] }; // Ignorez `z` pour la transformation

            CoordinateTransformFactory ctFactory = new CoordinateTransformFactory();
            CoordinateTransform transform = ctFactory.createTransform(sourceCRS, destCRS);

            ProjCoordinate inputCoordinate = new ProjCoordinate(xyCoords[0], xyCoords[1]);
            ProjCoordinate outputCoordinate = new ProjCoordinate();

            transform.transform(inputCoordinate, outputCoordinate);

            // Format the transformed coordinates
            StringBuilder result = new StringBuilder();
            result.append(String.format("%.7f;%.7f", outputCoordinate.x, outputCoordinate.y));
            result.append(String.format(";%.7f", z)); // Ajoutez `z` sans transformation

            result.append(zvide);
            return result.toString().replace("NaN", "null");

        } catch (Exception e) {
            throw new Cs2csException(e.getMessage());
        }
    }

}
