package uvs_application

case class Person(protected var name: String, protected var age: Int)
